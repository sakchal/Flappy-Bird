/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 enemy enemy.png 
 * Time-stamp: Thursday 11/10/2022, 01:39:29
 * 
 * Image Information
 * -----------------
 * enemy.png 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENEMY_H
#define ENEMY_H

extern const unsigned short enemy[900];
#define ENEMY_SIZE 1800
#define ENEMY_LENGTH 900
#define ENEMY_WIDTH 30
#define ENEMY_HEIGHT 30

#endif

