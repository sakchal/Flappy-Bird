/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 flappybird flappybird.png 
 * Time-stamp: Thursday 11/10/2022, 01:19:43
 * 
 * Image Information
 * -----------------
 * flappybird.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLAPPYBIRD_H
#define FLAPPYBIRD_H

extern const unsigned short flappybird[400];
#define FLAPPYBIRD_SIZE 800
#define FLAPPYBIRD_LENGTH 400
#define FLAPPYBIRD_WIDTH 20
#define FLAPPYBIRD_HEIGHT 20

#endif

