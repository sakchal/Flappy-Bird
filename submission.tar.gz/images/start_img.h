/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 start_img start_img.png 
 * Time-stamp: Wednesday 11/09/2022, 17:58:50
 * 
 * Image Information
 * -----------------
 * start_img.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef START_IMG_H
#define START_IMG_H

extern const unsigned short start_img[38400];
#define START_IMG_SIZE 76800
#define START_IMG_LENGTH 38400
#define START_IMG_WIDTH 240
#define START_IMG_HEIGHT 160

#endif

