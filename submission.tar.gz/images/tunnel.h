/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 tunnel tunnel.png 
 * Time-stamp: Thursday 11/10/2022, 01:25:14
 * 
 * Image Information
 * -----------------
 * tunnel.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TUNNEL_H
#define TUNNEL_H

extern const unsigned short tunnel[1850];
#define TUNNEL_SIZE 3700
#define TUNNEL_LENGTH 1850
#define TUNNEL_WIDTH 50
#define TUNNEL_HEIGHT 37

#endif

